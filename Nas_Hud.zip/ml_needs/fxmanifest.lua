fx_version "adamant"
rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'
game "rdr3"

client_scripts { 
	'client.lua',
	'hud.lua',
	'vending.lua',
}

server_scripts {
'server.lua',
}

exports {
	"ml_thirst",
	"ml_hunger",
	"ml_stress",
}