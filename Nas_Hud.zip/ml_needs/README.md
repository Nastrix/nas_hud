# made by 
mrlupo & duck


# ml_needs


Add ensure ml_needs to your server.cfg

Add water and bread  as a usable item in inventory config

Add water and bread  as a item for sale in your shops

# What this is
this is a basic food and water on a timer
has drinking anin
has eating anim 


resets stats after player is revived/healed just trigger this in redemrp_respawn = TriggerEvent("fsn_needs:resetall")

# req 
redemrp_roleplay

# info

please remember this is a very basic script for yous to have fun with :)
